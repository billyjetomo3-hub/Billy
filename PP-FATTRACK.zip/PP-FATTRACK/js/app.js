(() => {
  "use strict";

  const KEYS = {
    users: "fittrack_users",
    session: "fittrack_session",
    routines: "fittrack_routines",
    exercises: "fittrack_exercises",
    activities: "fittrack_activities",
    weights: "fittrack_weight_entries",
    calendar: "fittrack_calendar",
    settings: "fittrack_settings"
  };
  const EXERCISES = [
    ["push-ups","Push-ups","Chest","Chest, shoulders, triceps","None","Beginner","Build upper-body strength with a controlled bodyweight press.","3 × 10–15"],
    ["squats","Bodyweight Squats","Legs","Quads, glutes","None","Beginner","Sit your hips back and keep your chest lifted as you squat.","3 × 12–15"],
    ["lunges","Alternating Lunges","Legs","Quads, glutes","None","Beginner","Step forward with control and lower both knees before switching sides.","3 × 10 each"],
    ["plank","Forearm Plank","Core","Abs, deep core","None","Beginner","Keep a straight line from shoulders to heels while bracing your core.","3 × 30 sec"],
    ["jumping-jacks","Jumping Jacks","Cardio","Full body","None","Beginner","Jump feet apart as arms lift overhead, then return smoothly.","3 × 30 sec"],
    ["dumbbell-rows","Dumbbell Rows","Back","Lats, upper back","Dumbbells","Intermediate","Hinge at the hips and pull each elbow toward your ribs.","3 × 10 each"],
    ["shoulder-press","Dumbbell Shoulder Press","Shoulders","Deltoids, triceps","Dumbbells","Intermediate","Press weights overhead without arching your lower back.","3 × 10"],
    ["bicep-curls","Bicep Curls","Arms","Biceps","Dumbbells","Beginner","Keep elbows by your sides and curl with a steady tempo.","3 × 12"],
    ["glute-bridges","Glute Bridges","Legs","Glutes, hamstrings","None","Beginner","Drive through your heels and squeeze your glutes at the top.","3 × 15"],
    ["mountain-climbers","Mountain Climbers","Core","Core, shoulders","None","Intermediate","From a high plank, alternate bringing knees forward at a steady pace.","3 × 30 sec"],
    ["burpees","Burpees","Full Body","Full body","None","Advanced","Move between a squat, plank, and standing position at your pace.","3 × 8"],
    ["calf-raises","Calf Raises","Legs","Calves","None","Beginner","Rise onto your toes, pause, and lower your heels slowly.","3 × 15"],
    ["cycling","Easy Cycling","Cardio","Cardiovascular","Bicycle","Beginner","Ride at a conversational pace and adjust duration to your fitness.","1 × 20 min"],
    ["childs-pose","Child's Pose","Flexibility","Back, hips","Mat","Beginner","Breathe slowly while gently resting your hips toward your heels.","2 × 30 sec"]
  ].map(([id,name,category,muscles,equipment,difficulty,description,suggested]) => ({id,name,category,muscles,equipment,difficulty,description,suggested, instructions: description}));
const ICON = {
  dashboard: `<svg class="ft-icon" viewBox="0 0 24 24" aria-hidden="true"><title>Dashboard</title><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><circle cx="10.5" cy="10.5" r="1.5" fill="var(--acid)"/><animate attributeName="opacity" values="1;0.4;1" dur="2s" repeatCount="indefinite"/></svg>`,
  routines: `<svg class="ft-icon" viewBox="0 0 24 24" aria-hidden="true"><title>Workouts</title><path d="M9 5H7a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h2"/><path d="M15 5h2a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-2"/><path d="M9 17h6" stroke-linecap="butt"/><path d="M7 7h10" stroke-linecap="butt"/></svg>`,
  library: `<svg class="ft-icon" viewBox="0 0 24 24" aria-hidden="true"><title>Exercise Lab</title><path d="M7 5h10l-2 14H9z"/><path d="M3 5v14h18V5"/><path d="M7 15h10"/><path d="M9 11h6"/></svg>`,
  activities: `<svg class="ft-icon" viewBox="0 0 24 24" aria-hidden="true"><title>Activity Log</title><path d="M3 12l3-3 3 3 3-3 3 3M3 12l3 3 3-3 3 3 3-3" stroke-linecap="round"/><circle cx="3" cy="12" r="1" fill="var(--acid)"/><animate attributeName="opacity" values="1;0.3;1" dur="1.5s" repeatCount="indefinite"/></svg>`,
  progress: `<svg class="ft-icon" viewBox="0 0 24 24" aria-hidden="true"><title>Progress</title><path d="M3 20l3-4 2 3 4-5 2 4" fill="none"/><path d="M3 20l3-4 2 3 4-5 2 4" fill="none" stroke="var(--acid)" stroke-dasharray="20" stroke-dashoffset="20"><animate attributeName="stroke-dashoffset" from="20" to="0" dur="1s" fill="freeze"/></svg>`,
  calendar: `<svg class="ft-icon" viewBox="0 0 24 24" aria-hidden="true"><title>Calendar</title><rect x="3" y="4" width="18" height="16" rx="2" ry="2"/><path d="M16 2v4M8 2v4M3 10h18"/><rect x="9" y="13" width="2" height="2" fill="var(--acid)"/></svg>`,
  settings: `<svg class="ft-icon" viewBox="0 0 24 24" aria-hidden="true"><title>Settings</title><circle cx="12" cy="12" r="4"/><path d="M12 6v2M12 16v2M6 12h2M16 12h2M9.33 9.33l1.41 1.41M15.66 15.66l1.41 1.41M9.33 15.66l1.41-1.41M15.66 9.33l-1.41 1.41"/></svg>`
};
function ftIcon(name, cls = "") {
  const svg = ICON[name];
  if (!svg) return "";
  return svg.replace('class="ft-icon"', 'class="ft-icon ' + cls + '"');
}
const NAV = [
    ["dashboard","dashboard","Dashboard"], ["routines","routines","Workouts"], ["library","library","Exercise Lab"],
    ["activities","activities","Activity Log"], ["progress","progress","Progress"], ["calendar","calendar","Calendar"],
    ["settings","settings","Profile"]
];
  const $ = (selector, root = document) => root.querySelector(selector);
  const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
  const uid = prefix => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;
  const dateKey = date => new Date(date).toISOString().slice(0,10);
  const localDate = (date = new Date()) => {
    const d = new Date(date);
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0,10);
  };
  const read = (key, fallback = []) => {
    try {
      const value = JSON.parse(localStorage.getItem(key) || "null");
      return Array.isArray(fallback) ? (Array.isArray(value) ? value : fallback) : (value && typeof value === "object" ? value : fallback);
    } catch (error) {
      console.warn(`Could not read ${key}; using an empty value.`, error);
      return fallback;
    }
  };
  const write = (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); }
    catch (error) { console.error(`Could not save ${key}.`, error); toast("Could not save data. Check available browser storage."); }
  };
  let user = null;
  let view = "dashboard";
  let authMode = "signup";
  let modalCleanup = null;
  let activeSession = null;
  let restTimer = null;
  let toastTimer = null;
  const chartFrames = new Map();

  const owned = key => read(key).filter(item => item && item.userId === user?.id);
  const saveOwned = (key, items) => {
    const all = read(key);
    const others = all.filter(item => item?.userId !== user?.id);
    write(key, [...others, ...items]);
  };
  const settings = () => read(KEYS.settings, {})[user?.id] || {};
  const saveSettings = patch => write(KEYS.settings, { ...read(KEYS.settings, {}), [user.id]: { ...settings(), ...patch } });
  const routines = () => owned(KEYS.routines);
  const activities = () => owned(KEYS.activities);
  const weights = () => owned(KEYS.weights).sort((a,b) => a.date.localeCompare(b.date));
  const schedules = () => owned(KEYS.calendar);
  const customExercises = () => owned(KEYS.exercises);
  const exerciseList = () => [...EXERCISES, ...customExercises()];
  const exerciseById = id => exerciseList().find(exercise => exercise.id === id);
  const fmtDate = (date, options = { month: "short", day: "numeric" }) => new Date(`${date}T12:00:00`).toLocaleDateString(undefined, options);
  const thisWeekStart = (date = new Date()) => { const d = new Date(date); d.setHours(0,0,0,0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d; };
  const weekDates = (offset = 0) => { const start = thisWeekStart(); start.setDate(start.getDate() + offset * 7); return Array.from({length:7}, (_,i) => { const d = new Date(start); d.setDate(start.getDate()+i); return localDate(d); }); };
  const navButton = ([id, icon, label]) => `<button class="nav-link ${view===id?"active":""}" data-view="${id}" aria-label="${label}">${ftIcon(icon)}<span>${label}</span></button>`;

  function toast(message) {
    const root = $("#toast-root");
    if (!root) return;
    const item = document.createElement("div");
    item.className = "toast";
    item.textContent = message;
    root.replaceChildren(item);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      item.classList.add("is-leaving");
      setTimeout(() => item.remove(), 280);
    }, 3200);
  }

  /* ---------- Motion helpers ---------- */
  const prefersReducedMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function applyStagger(root, selector, step = 55) {
    if (!root || prefersReducedMotion()) return;
    root.querySelectorAll(selector).forEach((element, index) => {
      element.style.setProperty("--i", index);
      element.style.setProperty("animation-delay", `${index * step}ms`);
    });
  }

  function animateCountUp(element) {
    if (!element || prefersReducedMotion()) return;
    const raw = element.dataset.count;
    if (raw === undefined) return;
    const target = Number(raw);
    if (!Number.isFinite(target)) return;
    const decimals = (String(raw).split(".")[1] || "").length;
    const duration = 900;
    const start = performance.now();
    const step = now => {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      element.textContent = (target * eased).toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
      if (progress < 1) requestAnimationFrame(step);
      else element.textContent = (target).toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
    };
    requestAnimationFrame(step);
  }

  function animateCountUps(root) {
    if (!root) return;
    root.querySelectorAll("[data-count]").forEach(animateCountUp);
  }

  /* ---------- Chart animation manager ---------- */
  function cancelChartFrame(key) {
    if (chartFrames.has(key)) {
      cancelAnimationFrame(chartFrames.get(key));
      chartFrames.delete(key);
    }
  }

  function cancelAllChartFrames() {
    chartFrames.forEach(id => cancelAnimationFrame(id));
    chartFrames.clear();
  }

  function runChartAnimation(key, paint, duration) {
    cancelChartFrame(key);
    if (!duration) { paint(performance.now(), 1); return; }
    const startedAt = performance.now();
    const tick = now => {
      const progress = Math.min(1, (now - startedAt) / duration);
      paint(now, progress);
      if (progress < 1) chartFrames.set(key, requestAnimationFrame(tick));
      else chartFrames.delete(key);
    };
    chartFrames.set(key, requestAnimationFrame(tick));
  }

  function decorateArrowButtons(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.parentElement.closest("button") && /[←→↑↓]/.test(node.nodeValue) && !node.parentElement.closest(".arrow-glyph")) textNodes.push(node);
    }
    textNodes.forEach(node => {
      const fragment = document.createDocumentFragment();
      node.nodeValue.split(/([←→↑↓])/).forEach(part => {
        if (/^[←→↑↓]$/.test(part)) {
          const arrow = document.createElement("span");
          arrow.className = "arrow-glyph";
          arrow.setAttribute("aria-hidden", "true");
          arrow.textContent = part;
          fragment.append(arrow);
        } else {
          fragment.append(document.createTextNode(part));
        }
      });
      node.replaceWith(fragment);
    });
  }

  async function hashPassword(password) {
    if (!globalThis.crypto?.subtle || !globalThis.TextEncoder) throw new Error("Secure password hashing is unavailable in this browser. Use a modern browser on localhost or HTTPS.");
    const bytes = new TextEncoder().encode(password);
    const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2,"0")).join("");
  }

  function renderAuth(error = "") {
    document.body.classList.remove("dashboard-background");
    document.body.classList.add("main-site-background");
    $("#app").innerHTML = `<main class="auth-wrap main-site-background"><section class="auth-card">
      <div class="brand"><div class="brand-mark"><img src="assets/fittrack-mark.svg" alt=""></div><div class="brand-copy">FIT<span>TRACK</span><small>MOVE BETTER. GET STRONGER.</small></div></div>
      <h1>${authMode==="signup"?"OWN THE":"WELCOME"} <span>${authMode==="signup"?"NIGHT.":"BACK."}</span></h1>
      <p>${authMode==="signup"?"Build your training rhythm. Your records stay on this device.":"Sign in to pick up where your last session left off."}</p>
      ${error?`<div class="auth-error" role="alert">${esc(error)}</div>`:""}
      <form id="auth-form" class="form-grid">
        ${authMode==="signup"?`<div class="form-field full"><label for="auth-name">FULL NAME</label><input class="field" id="auth-name" name="name" required maxlength="60" autocomplete="name"></div><div class="form-field"><label for="auth-username">USERNAME</label><input class="field" id="auth-username" name="username" required maxlength="24" autocomplete="username" pattern="[A-Za-z0-9_]{3,24}" title="Use 3–24 letters, numbers, or underscores."></div><div class="form-field"><label for="auth-email">EMAIL</label><input class="field" id="auth-email" name="email" type="email" required autocomplete="email"></div>`:`<div class="form-field full"><label for="auth-login">USERNAME OR EMAIL</label><input class="field" id="auth-login" name="login" required autocomplete="username"></div>`}
        <div class="form-field full"><label for="auth-password">PASSWORD</label><div class="field-with-action"><input class="field" id="auth-password" name="password" type="password" required minlength="8" autocomplete="${authMode==="signup"?"new-password":"current-password"}"><button type="button" class="field-action" data-toggle-password="auth-password" aria-label="Show password" aria-pressed="false">Show</button></div></div>
        ${authMode==="signup"?`<div class="form-field full"><label for="auth-confirm">CONFIRM PASSWORD</label><div class="field-with-action"><input class="field" id="auth-confirm" name="confirm" type="password" required minlength="8" autocomplete="new-password"><button type="button" class="field-action" data-toggle-password="auth-confirm" aria-label="Show password" aria-pressed="false">Show</button></div></div>`:`<label class="form-field full text-muted" style="display:flex;align-items:center;gap:8px"><span><input type="checkbox" name="remember" checked> Keep me signed in on this device</span></label>`}
        <div class="form-field full"><button class="btn btn-primary btn-block" type="submit">${authMode==="signup"?"CREATE MY ACCOUNT":"ENTER FITTRACK"} <span>←</span></button></div>
      </form>
      <p>${authMode==="signup"?"Already training here?":"New to the crew?"} <button class="auth-switch" data-auth-switch>${authMode==="signup"?"Sign in":"Create an account"}</button></p>
      <div class="auth-note">Demo authentication is stored in this browser only. Passwords are hashed locally, but browser storage is not secure production authentication and does not sync between devices.</div>
    </section></main>`;
    $("#auth-form").addEventListener("submit", onAuthSubmit);
    document.querySelectorAll("[data-toggle-password]").forEach(button=>{
      button.addEventListener("click",()=>{
        const input=document.getElementById(button.dataset.togglePassword);
        if(!input)return;
        const hidden=input.type==="password";
        input.type=hidden?"text":"password";
        button.textContent=hidden?"Hide":"Show";
        button.setAttribute("aria-pressed",String(hidden));
        button.setAttribute("aria-label",hidden?"Hide password":"Show password");
      });
    });
    $("[data-auth-switch]").addEventListener("click", () => { window.FittrackSounds?.activate(); window.FittrackSounds?.playClick(); authMode = authMode === "signup" ? "login" : "signup"; renderAuth(); });
  }

  async function onAuthSubmit(event) {
    event.preventDefault();
    window.FittrackSounds?.activate();
    const form = new FormData(event.currentTarget);
    const password = String(form.get("password") || "");
    try {
      const users = read(KEYS.users).filter(item => item && typeof item === "object");
      if (authMode === "signup") {
        const username = String(form.get("username") || "").trim();
        const email = String(form.get("email") || "").trim().toLowerCase();
        const name = String(form.get("name") || "").trim();
        if (password.length < 8) return renderAuth("Use a password with at least 8 characters.");
        if (password !== String(form.get("confirm") || "")) return renderAuth("Your passwords do not match.");
        if (users.some(item => String(item.username || "").toLowerCase() === username.toLowerCase())) return renderAuth("That username is already registered.");
        if (users.some(item => String(item.email || "").toLowerCase() === email)) return renderAuth("That email is already registered.");
        user = { id: uid("user"), name, username, email, passwordHash: await hashPassword(password), createdAt: new Date().toISOString() };
        write(KEYS.users, [...users, user]);
        const allSettings = read(KEYS.settings, {});
        write(KEYS.settings, { ...allSettings, [user.id]: { unit: "kg", theme: "dark", goal: "General Fitness", favorites: [] } });
        write(KEYS.session, { userId: user.id, remember: true });
      } else {
        const login = String(form.get("login") || "").trim().toLowerCase();
        const passwordHash = await hashPassword(password);
        user = users.find(item => (String(item.username || "").toLowerCase() === login || String(item.email || "").toLowerCase() === login) && item.passwordHash === passwordHash) || null;
        if (!user) return renderAuth("Those sign-in details don't match an account.");
        const session = { userId: user.id, remember: Boolean(form.get("remember")) };
        if(session.remember) {
          write(KEYS.session, session);
          sessionStorage.removeItem(KEYS.session);
        } else {
          localStorage.removeItem(KEYS.session);
          sessionStorage.setItem(KEYS.session, JSON.stringify(session));
        }
      }
      applyTheme();
      renderApp();
      window.FittrackSounds?.playSuccess();
    } catch (error) {
      renderAuth(error.message || "We couldn't complete sign in.");
    }
  }

  function restoreUser() {
    let session = read(KEYS.session, {});
    if(!session.userId) {
      try { session = JSON.parse(sessionStorage.getItem(KEYS.session) || "{}"); }
      catch(error) { console.warn("Could not read the temporary session.", error); session = {}; }
    }
    const users = read(KEYS.users);
    user = users.find(item => item && typeof item === "object" && item.id === session.userId) || null;
    if (!user) {
      localStorage.removeItem(KEYS.session);
      sessionStorage.removeItem(KEYS.session);
    }
  }

  function applyTheme() {
    document.documentElement.dataset.theme = settings().theme === "light" ? "light" : "dark";
  }

  function renderApp() {
    if (!user) return renderAuth();
    applyTheme();
    document.body.classList.remove("main-site-background");
    document.body.classList.add("dashboard-background");

    $("#app").innerHTML = `<div class="app-shell dashboard-background">
      <aside class="sidebar"><a href="#" class="brand" data-view="dashboard"><div class="brand-mark"><img src="assets/fittrack-mark.svg" alt=""></div><div class="brand-copy">FIT<span>TRACK</span><small>MOVE BETTER. GET STRONGER.</small></div></a>
        <div class="nav-label">Training hub</div><nav class="nav-list" aria-label="Main navigation">${NAV.map(navButton).join("")}</nav>
        <div class="sidebar-bottom"><div class="side-promo"><strong>YOUR PACE.<br>YOUR RULES.</strong><p>Small reps. Big energy. Keep showing up.</p><button class="btn btn-small btn-pink" data-view="routines">${ftIcon("add")}Build a session ←</button></div>
          <div class="sidebar-user"><div class="avatar">${esc(user.name.split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase())}</div><div class="user-copy"><strong>${esc(user.name)}</strong><small>@${esc(user.username)}</small></div><button class="icon-btn ft-icon-button" data-action="logout" aria-label="Log out">${ftIcon("logout","ft-icon-sm")}>←</button></div>
        </div>
      </aside>
      <main class="main-area"><header class="topbar"><div><div class="eyebrow">FITTRACK / YOUR TRAINING SPACE</div><h1 class="page-heading" id="page-heading"></h1></div><div class="top-actions"><div class="date-chip">${new Date().toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"})}</div><button class="profile-button" data-view="settings" aria-label="Open profile and settings"><span class="profile-initials">${esc(user.name.split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase())}</span><span class="profile-button-label">Profile</span></button></div></header><div id="content" class="content"></div></main>
    </div><div id="modal-root"></div>`;
    decorateArrowButtons($("#app"));
    applyStagger($("#app"), ".nav-link");
    $("#app").addEventListener("click", onAppClick);
    $("#app").addEventListener("submit", onAppSubmit);
    $("#app").addEventListener("change", onAppChange);
    renderView();
  }

  function renderView() {
    if (!user) return;
    applyTheme();
    const titles = {dashboard:"Dashboard",routines:"Workout deck",library:"Exercise lab",activities:"Activity log",progress:"Progress track",calendar:"Weekly calendar",settings:"Profile"};
    $("#page-heading").textContent = titles[view] || "Dashboard";
    document.querySelectorAll(".nav-link").forEach(button => button.classList.toggle("active",button.dataset.view===view));
    const renderers = { dashboard: renderDashboard, routines: renderRoutines, library: renderLibrary, activities: renderActivities, progress: renderProgress, calendar: renderCalendar, settings: renderSettings };
    const content = $("#content");
    content.innerHTML = (renderers[view] || renderDashboard)();
    content.classList.remove("view-transition");
    void content.offsetWidth;
    content.classList.add("view-transition");
    decorateArrowButtons(content);
    applyStagger(content, ".stats-grid > .stat-card, .quick-grid > .quick-card, .cards-grid > .item-card, .dashboard-grid > .card, .grid > .card");
    applyStagger(content, ".calendar-grid > .calendar-day", 28);
    animateCountUps(content);
    if (view === "progress") {
      drawWeightChart();
      drawWorkoutFrequency();
    } else {
      cancelAllChartFrames();
    }
  }

  function renderDashboard() {
    const week = weekDates(0);
    const logged = activities();
    const weekActivities = logged.filter(item => week.includes(item.date));
    const sessions = weekActivities.filter(item => item.routineId);
    const minutes = weekActivities.reduce((total,item)=>total+Number(item.duration||0),0);
    const recentWeights = weights();
    const currentWeight = recentWeights.at(-1);
    const streak = computeStreak(logged);
    const maxMinutes = Math.max(1,...week.map(day=>logged.filter(item=>item.date===day).reduce((sum,item)=>sum+Number(item.duration||0),0)));
    const recent = [...logged].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,4);
    const next = [...schedules()].filter(item=>item.status!=="completed" && item.date>=localDate()).sort((a,b)=>a.date.localeCompare(b.date))[0];
    return `<div class="view-intro"><div><h2 class="section-title">The next rep starts here.</h2><p>Hey ${esc(user.name.split(" ")[0])} — show up, find your rhythm, and stack another win.</p></div><button class="btn btn-primary" data-modal="activity">${ftIcon("add")}＋ Log activity</button></div>
      <section class="hero-card"><div class="hero-kicker">Training mode // ON</div><h2 class="hero-title">MOVE <span>LOUDER.</span><br>GET STRONGER.</h2><p>${next?`Next up: ${esc(next.routineName)} on ${fmtDate(next.date)}${next.time?` at ${esc(next.time)}`:""}.`:"Build momentum one session at a time. Your next workout is yours to make."}</p><div class="hero-actions"><button class="btn btn-primary" data-view="routines">${ftIcon("routines")}Pick a workout ←</button><button class="btn btn-quiet" data-view="calendar">Open calendar</button></div></section>
      <div class="grid stats-grid">
        ${statCard("WORKOUTS THIS WEEK",sessions.length,"sessions","pink")}
        ${statCard("ACTIVE MINUTES",minutes,"min this week","acid")}
        ${statCard("LATEST WEIGHT",currentWeight?`${fmtNumber(currentWeight.value)}`:"—",currentWeight?settings().unit||"kg":"add an entry","cyan")}
        ${statCard("DAY STREAK",streak,"active days","violet")}
      </div>
      <div class="grid dashboard-grid">
        <div class="grid">
          <section class="card panel"><div class="panel-head"><h2 class="section-title">Seven-day signal</h2><span class="tag">MINUTES / DAY</span></div><div class="bars">${week.map((day,index)=>{ const sum=logged.filter(item=>item.date===day).reduce((n,a)=>n+Number(a.duration||0),0); const height=sum?Math.max(10,sum/maxMinutes*100):5; return `<div class="bar-day"><div class="bar-track"><div class="bar-fill ${day===localDate()?"today":""}" style="height:${height}%;--i:${index}"></div></div><span>${new Date(`${day}T12:00`).toLocaleDateString(undefined,{weekday:"short"}).slice(0,2)}</span></div>`; }).join("")}</div></section>
          <section class="card panel"><div class="panel-head"><h2 class="section-title">Recent sessions</h2><button class="btn btn-small btn-quiet" data-view="activities">View all ←</button></div>${recent.length?`<div class="list">${recent.map(activityRow).join("")}</div>`:`<div class="empty-state"><strong>Your story starts with one session.</strong>Log a workout or an activity to see your progress here.<br><button class="btn btn-small btn-pink" style="margin-top:12px" data-modal="activity">Log your first activity</button></div>`}</section>
        </div>
        <section class="card panel"><div class="panel-head"><h2 class="section-title">Quick actions</h2><span class="text-pink">✓</span></div><div class="grid quick-grid quick-grid-2">
          ${quickCard(ftIcon("routines"),"Create workout","Build your routine","routines")}${quickCard(ftIcon("library"),"Find moves","Explore exercises","library")}${quickCard(ftIcon("activities"),"Add activity","Log your movement","modal:activity")}${quickCard(ftIcon("weight"),"Track weight","Add a progress entry","modal:weight")}
        </div><hr class="divider"><div class="panel-head"><h2 class="section-title">Your next level</h2></div><p class="text-muted" style="font-size:11px">Pick a goal and make your training your own.</p><button class="btn btn-quiet btn-block" data-view="settings">${esc(settings().goal||"Set a fitness goal")} →</button></section>
      </div>`;
  }
  function statCard(label,value,unit,accent) {
    const raw = typeof value === "number" ? String(value) : String(value ?? "");
    const countable = /^\d+(\.\d+)?$/.test(raw);
    const display = countable ? Number(raw).toLocaleString(undefined,{maximumFractionDigits:1}) : esc(value);
    const statIcons = {WORKOUTS:"routines",ACTIVE:"routines",LATEST:"weight",DAY:"calendar",ALL:"activities",TOTAL:"duration"};
    const sKey = Object.keys(statIcons).find(k => label.includes(k));
    const sIcon = sKey ? ftIcon(statIcons[sKey],"ft-icon-sm") : "";
    return `<div class="card stat-card">${sIcon}<span class="stat-label">${label}</span><strong class="stat-value accent-${accent}"${countable?` data-count="${raw}"`:""}>${display}</strong><span class="stat-unit">${esc(unit)}</span></div>`;
  }
  function quickCard(icon,title,description,target) { return `<button class="card quick-card" data-${target.startsWith("modal:")?"modal":"view"}="${target.replace("modal:","")}"><span class="quick-icon">${icon}</span><strong>${title}</strong><span>${description}</span></button>`; }
  function activityRow(item, actions = false) {
    return `<div class="list-row"><div class="row-icon">${ftIcon("routines","ft-icon-sm")}</div><div class="list-row-main"><strong>${esc(item.name)}</strong><small>${fmtDate(item.date)} · ${Number(item.duration)||0} min · ${esc(item.type||"Workout")}${item.exerciseCount?` · ${Number(item.exerciseCount)} exercises`:""}</small></div>${actions?`<button class="btn btn-small btn-quiet ft-icon-button" data-action="edit-activity" data-id="${esc(item.id)}">${ftIcon("edit","ft-icon-sm")}Edit</button><button class="btn btn-small btn-quiet btn-danger ft-icon-button" data-action="delete-activity" data-id="${esc(item.id)}">${ftIcon("delete","ft-icon-sm")}Delete</button>`:`<span class="tag">DONE</span>`}</div>`;
  }
  function computeStreak(items) {
    const days = new Set(items.map(item=>item.date));
    let date = new Date(); if (!days.has(localDate(date))) date.setDate(date.getDate()-1);
    let count=0; while(days.has(localDate(date))){ count++; date.setDate(date.getDate()-1); } return count;
  }
  const fmtNumber = value => Number(value).toLocaleString(undefined,{maximumFractionDigits:1});

  function renderRoutines() {
    const list = routines();
    return `<div class="view-intro"><div><h2 class="section-title">Build your own rhythm.</h2><p>Create a routine from the move library, then run it as a guided workout.</p></div><button class="btn btn-primary" data-modal="routine">＋ New workout</button></div>
      ${list.length?`<div class="grid cards-grid">${list.map(routine=>`<article class="card item-card"><div class="eyebrow">${esc(routine.goal||"GENERAL FITNESS")} · ${esc(routine.difficulty||"BEGINNER")}</div><h3>${esc(routine.name)}</h3><p>${esc(routine.description||"Make this session your own.")}</p><div class="tag-row"><span class="tag">${routine.exercises.length} moves</span><span class="tag">${Number(routine.durationMinutes)||0} min</span>${routine.target?`<span class="tag">${esc(routine.target)}</span>`:""}</div><div class="item-actions"><button class="btn btn-small btn-primary" data-action="start-workout" data-id="${esc(routine.id)}">▶ Start</button><button class="btn btn-small" data-action="edit-routine" data-id="${esc(routine.id)}">Edit</button><button class="btn btn-small" data-action="duplicate-routine" data-id="${esc(routine.id)}">Duplicate</button><button class="btn btn-small btn-quiet btn-danger" data-action="delete-routine" data-id="${esc(routine.id)}">Delete</button></div></article>`).join("")}</div>`:`<div class="empty-state"><strong>Your workout deck is empty.</strong>Build a custom routine or explore the exercise lab to find your first moves.<br><button class="btn btn-small btn-pink" style="margin-top:12px" data-modal="routine">Create a routine</button></div>`}`;
  }

  function renderLibrary() {
    const favorites = settings().favorites || [];
    const exercises = exerciseList();
    return `<div class="view-intro"><div><h2 class="section-title">Move library.</h2><p>Explore bodyweight basics, strength builders, and recovery moves. Add custom exercises whenever you like.</p></div><button class="btn btn-primary" data-modal="exercise">＋ Custom move</button></div>
      <div class="filters"><input class="field filter-field" id="exercise-search" placeholder="Search moves or muscles…"><select class="select filter-select" id="exercise-category"><option value="">All muscle groups</option>${["Chest","Back","Shoulders","Arms","Legs","Core","Cardio","Full Body","Flexibility"].map(x=>`<option>${x}</option>`).join("")}</select><select class="select filter-select" id="exercise-difficulty"><option value="">All levels</option><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select><select class="select filter-select" id="exercise-equipment"><option value="">All equipment</option>${[...new Set(exercises.map(x=>x.equipment))].sort().map(x=>`<option>${esc(x)}</option>`).join("")}</select></div>
      <div id="exercise-cards" class="grid cards-grid">${exercises.map(exercise=>exerciseCard(exercise,favorites)).join("")}</div>`;
  }
  function exerciseCard(exercise,favorites) {
    return `<article class="card item-card" data-exercise-card data-search="${esc(`${exercise.name} ${exercise.muscles} ${exercise.category}`.toLowerCase())}" data-category="${esc(exercise.category)}" data-difficulty="${esc(exercise.difficulty)}" data-equipment="${esc(exercise.equipment)}"><div class="eyebrow">${esc(exercise.category)} · ${esc(exercise.difficulty)}</div><h3>${esc(exercise.name)} ${favorites.includes(exercise.id)?"<span class=\"text-acid\">★</span>":""}</h3><p>${esc(exercise.description)}</p><div class="tag-row"><span class="tag">${esc(exercise.muscles)}</span><span class="tag">${esc(exercise.equipment)}</span><span class="tag">${esc(exercise.suggested)}</span></div><div class="item-actions"><button class="btn btn-small btn-primary" data-action="add-exercise-to-routine" data-id="${esc(exercise.id)}">＋ Add to routine</button><button class="btn btn-small" data-action="exercise-details" data-id="${esc(exercise.id)}">Details</button><button class="btn btn-small btn-quiet" data-action="favorite-exercise" data-id="${esc(exercise.id)}">${favorites.includes(exercise.id)?"★":"☆"}</button>${exercise.userId?`<button class="btn btn-small" data-action="edit-exercise" data-id="${esc(exercise.id)}">Edit</button><button class="btn btn-small btn-quiet btn-danger ft-icon-button" data-action="delete-exercise" data-id="${esc(exercise.id)}">×</button>`:""}</div></article>`;
  }

  function renderActivities() {
    const list = [...activities()].sort((a,b)=>b.date.localeCompare(a.date));
    const total = list.reduce((sum,item)=>sum+Number(item.duration||0),0);
    return `<div class="view-intro"><div><h2 class="section-title">Every session counts.</h2><p>Log workouts and everyday movement. Edit or remove an entry whenever you need to.</p></div><button class="btn btn-primary" data-modal="activity">${ftIcon("add")}＋ Log activity</button></div>
      <div class="grid stats-grid" style="grid-template-columns:repeat(2,minmax(0,1fr))">${statCard("ALL ACTIVITIES",list.length,"logged entries","pink")}${statCard("TOTAL MOVEMENT",total,"minutes recorded","acid")}</div>
      <div class="filters"><input id="activity-search" class="field filter-field" placeholder="Search your activity log…"><select id="activity-type-filter" class="select filter-select"><option value="">All activity types</option>${["Strength Training","Cardio","Walking","Running","Cycling","Sports","Yoga","Stretching","Other"].map(x=>`<option>${x}</option>`).join("")}</select><input id="activity-from" class="field filter-select" type="date" aria-label="From date"><input id="activity-to" class="field filter-select" type="date" aria-label="To date"><select id="activity-sort" class="select filter-select"><option value="date">Newest first</option><option value="duration">Longest first</option></select><button class="btn" data-action="export-csv">${ftIcon("save")}↓ Export CSV</button></div>
      <div id="activity-list" class="list">${list.length?list.map(item=>activityRow(item,true)).join(""):`<div class="empty-state"><strong>No activities logged yet.</strong>Record movement and start seeing your weekly totals.</div>`}</div>`;
  }

  function renderProgress() {
    const entries=weights(), unit=settings().unit||"kg", last=entries.at(-1), previous=entries.at(-2);
    const change=last&&previous?Number(last.value)-Number(previous.value):null;
    const period=Number($("#progress-range")?.value||30);
    const cutoff=new Date(); cutoff.setDate(cutoff.getDate()-period);
    const visible=entries.filter(item=>new Date(`${item.date}T12:00`)>=cutoff);
    const logged=activities();
    return `<div class="view-intro"><div><h2 class="section-title">Progress, your way.</h2><p>Your records, your timeline. This view is for tracking change, not judging it.</p></div><button class="btn btn-primary" data-modal="weight">＋ Add weight</button></div>
      <div class="grid dashboard-grid"><section class="card panel"><div class="panel-head"><h2 class="section-title">Weight history</h2><select id="progress-range" class="select" style="width:auto"><option value="30">Last 30 days</option><option value="90">Last 90 days</option><option value="365">Last year</option><option value="99999">All time</option></select></div><div class="weight-summary"><div><strong class="text-acid">${last?`${fmtNumber(last.value)} ${esc(unit)}`:"—"}</strong><span>Latest recorded</span></div><div><strong class="${change===null?"":change<=0?"text-acid":"text-pink"}">${change===null?"—":`${change>0?"+":""}${fmtNumber(change)} ${esc(unit)}`}</strong><span>Change since previous entry</span></div></div><div class="chart-wrap"><canvas id="weight-chart" aria-label="Weight history chart"></canvas></div>${visible.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Weight</th><th>Note</th><th>Action</th></tr></thead><tbody>${visible.slice().reverse().map(entry=>`<tr><td>${fmtDate(entry.date,{year:"numeric",month:"short",day:"numeric"})}</td><td>${fmtNumber(entry.value)} ${esc(unit)}</td><td>${esc(entry.note||"—")}</td><td><button class="btn btn-small" data-action="edit-weight" data-id="${esc(entry.id)}">Edit</button> <button class="btn btn-small btn-quiet btn-danger" data-action="delete-weight" data-id="${esc(entry.id)}">×</button></td></tr>`).join("")}</tbody></table></div>`:`<div class="empty-state">Add your first entry to start the timeline.</div>`}</section>
      <div class="grid"><section class="card panel"><div class="panel-head"><h2 class="section-title">Workout frequency</h2><span class="tag">THIS WEEK</span></div><div class="chart-wrap" style="height:180px"><canvas id="frequency-chart" aria-label="Completed workouts this week"></canvas></div></section><section class="card panel"><div class="panel-head"><h2 class="section-title">This week's movement</h2></div>${weekActivitySummary(logged)}</section><section class="card panel"><div class="panel-head"><h2 class="section-title">Your unit</h2></div><p class="text-muted" style="font-size:11px">Weight entries stay in the unit you select here.</p><select class="select" id="weight-unit"><option value="kg" ${unit==="kg"?"selected":""}>Kilograms (kg)</option><option value="lb" ${unit==="lb"?"selected":""}>Pounds (lb)</option></select><hr class="divider"><p class="text-muted" style="font-size:10px">A personal activity log, not medical advice. Weight changes can have many causes.</p></section></div></div>`;
  }
  function weekActivitySummary(logged) {
    return `<div class="list">${weekDates().map(day=>{const dayItems=logged.filter(x=>x.date===day);const mins=dayItems.reduce((n,x)=>n+Number(x.duration||0),0);return `<div class="list-row"><div class="list-row-main"><strong>${fmtDate(day,{weekday:"long",month:"short",day:"numeric"})}</strong><small>${dayItems.length} ${dayItems.length===1?"activity":"activities"}</small></div><span class="tag">${mins} min</span></div>`;}).join("")}</div>`;
  }
  function drawWeightChart() {
    const canvas=$("#weight-chart"); if(!canvas)return;
    const rect=canvas.getBoundingClientRect(), ratio=window.devicePixelRatio||1;
    canvas.width=Math.max(1,rect.width*ratio);canvas.height=Math.max(1,rect.height*ratio);
    const ctx=canvas.getContext("2d"); if(!ctx)return;
    ctx.scale(ratio,ratio);
    const data=weights().filter(item=>{const range=Number($("#progress-range")?.value||30);return new Date(`${item.date}T12:00`)>=new Date(Date.now()-range*86400000);});
    const w=rect.width,h=rect.height,pad={l:36,r:12,t:15,b:27};
    const rootStyle=getComputedStyle(document.documentElement);
    const text=rootStyle.getPropertyValue("--muted").trim();
    const line=rootStyle.getPropertyValue("--line").trim();
    const accent=rootStyle.getPropertyValue("--acid").trim()||"#B7FF38";
    const ink=rootStyle.getPropertyValue("--text").trim()||"#EDF2EA";
    ctx.clearRect(0,0,w,h);ctx.font="10px DM Sans";ctx.fillStyle=text;ctx.strokeStyle=line;ctx.lineWidth=1;
    if(!data.length){ctx.textAlign="center";ctx.fillText("Add a weight entry to start your chart",w/2,h/2);return;}
    const values=data.map(x=>Number(x.value)),min=Math.min(...values),max=Math.max(...values),spread=max-min||1;
    const x=i=>pad.l+(data.length===1?(w-pad.l-pad.r)/2:i/(data.length-1)*(w-pad.l-pad.r));
    const y=v=>pad.t+(max-v+spread*.12)/(spread*1.24)*(h-pad.t-pad.b);
    ctx.beginPath();ctx.moveTo(pad.l,pad.t);ctx.lineTo(pad.l,h-pad.b);ctx.lineTo(w-pad.r,h-pad.b);ctx.stroke();
    const animate = !prefersReducedMotion();
    const duration = animate ? 900 : 0;
    const paint = (now, progress = 1) => {
      const eased = 1-Math.pow(1-progress,3);
      const limit = Math.max(1,Math.ceil(eased*data.length));
      ctx.clearRect(0,0,w,h);
      ctx.font="10px DM Sans";ctx.fillStyle=text;ctx.strokeStyle=line;ctx.lineWidth=1;
      ctx.beginPath();ctx.moveTo(pad.l,pad.t);ctx.lineTo(pad.l,h-pad.b);ctx.lineTo(w-pad.r,h-pad.b);ctx.stroke();
      // Area fill under the line
      const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b);
      grad.addColorStop(0,`${accent}44`);grad.addColorStop(1,`${accent}00`);
      ctx.beginPath();ctx.moveTo(x(0),h-pad.b);
      data.slice(0,limit).forEach((item,i)=>ctx.lineTo(x(i),y(Number(item.value))));
      ctx.lineTo(x(Math.max(0,limit-1)),h-pad.b);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
      // Line
      ctx.strokeStyle=accent;ctx.lineWidth=2.5;ctx.lineJoin="round";ctx.lineCap="round";
      ctx.beginPath();
      data.slice(0,limit).forEach((item,i)=>i?ctx.lineTo(x(i),y(Number(item.value))):ctx.moveTo(x(i),y(Number(item.value))));
      ctx.stroke();
      // Points + labels
      data.slice(0,limit).forEach((item,i)=>{
        const isLast = i===limit-1;
        ctx.beginPath();ctx.arc(x(i),y(Number(item.value)),isLast?4.5:3.5,0,Math.PI*2);
        ctx.fillStyle=ink;ctx.fill();
        if(isLast){ctx.strokeStyle=accent;ctx.lineWidth=2;ctx.stroke();}
        if(data.length<9||i===0||isLast){ctx.fillStyle=text;ctx.textAlign="center";ctx.fillText(fmtDate(item.date,{month:"short",day:"numeric"}),x(i),h-8);}
      });
    };
    runChartAnimation("weight", paint, duration);
  }
  function drawWorkoutFrequency() {
    const canvas=$("#frequency-chart"); if(!canvas)return;
    const rect=canvas.getBoundingClientRect(),ratio=window.devicePixelRatio||1;
    canvas.width=Math.max(1,rect.width*ratio);canvas.height=Math.max(1,rect.height*ratio);
    const ctx=canvas.getContext("2d");if(!ctx)return;ctx.scale(ratio,ratio);
    const days=weekDates(),counts=days.map(day=>activities().filter(item=>item.date===day&&item.routineId).length);
    const width=rect.width,height=rect.height,pad={l:12,r:12,t:16,b:26},max=Math.max(1,...counts);
    const rootStyle=getComputedStyle(document.documentElement);
    const muted=rootStyle.getPropertyValue("--muted").trim();
    const accent=rootStyle.getPropertyValue("--acid").trim()||"#B7FF38";
    const ink=rootStyle.getPropertyValue("--text").trim()||"#EDF2EA";
    const gap=10,barWidth=(width-pad.l-pad.r-gap*6)/7;
    const animate=!prefersReducedMotion(),duration=animate?700:0;
    const paint=(now,progress=1)=>{
      const eased=1-Math.pow(1-progress,3);
      ctx.clearRect(0,0,width,height);
      days.forEach((day,index)=>{
        const x=pad.l+index*(barWidth+gap),barHeight=(height-pad.t-pad.b)*(counts[index]/max)*eased;
        const gradient=ctx.createLinearGradient(0,height-pad.b-barHeight,0,height-pad.b);
        gradient.addColorStop(0,accent);
        gradient.addColorStop(1,day===localDate()?"#6FD9C0":"#3F7A10");
        ctx.fillStyle=gradient;ctx.beginPath();
        const y=height-pad.b-Math.max(barHeight,4);ctx.roundRect(x,y,barWidth,Math.max(barHeight,4),4);ctx.fill();
        ctx.fillStyle=muted;ctx.font="10px DM Sans";ctx.textAlign="center";
        ctx.fillText(new Date(`${day}T12:00`).toLocaleDateString(undefined,{weekday:"short"}).slice(0,2),x+barWidth/2,height-8);
        if(counts[index]&&progress>0.6){ctx.fillStyle=ink;ctx.fillText(String(counts[index]),x+barWidth/2,y-5);}
      });
    };
    runChartAnimation("frequency", paint, duration);
  }

  function renderCalendar(offset=0) {
    const days=weekDates(offset), entries=schedules().filter(item=>days.includes(item.date));
    return `<div class="view-intro"><div><h2 class="section-title">Put it on the calendar.</h2><p>Scheduled sessions are plans, not completed activities. Mark a workout complete when you've finished it.</p></div><button class="btn btn-primary" data-modal="schedule">${ftIcon("add")}＋ Schedule workout</button></div>
      <div class="panel-head"><div class="inline-actions"><button class="btn btn-small ft-icon-button" data-action="calendar-shift" data-offset="${offset-1}">${ftIcon("back","ft-icon-sm")}← Prev</button><button class="btn btn-small" data-action="calendar-shift" data-offset="0">This week</button><button class="btn btn-small" data-action="calendar-shift" data-offset="${offset+1}">Next →</button></div><span class="text-muted">${fmtDate(days[0])} — ${fmtDate(days[6],{month:"short",day:"numeric",year:"numeric"})}</span></div>
      <div class="calendar-grid">${days.map(day=>{const date=new Date(`${day}T12:00`);const daily=entries.filter(e=>e.date===day);return `<div class="calendar-day ${day===localDate()?"is-today":""}"><div class="calendar-day-head"><strong>${date.toLocaleDateString(undefined,{weekday:"short"}).toUpperCase()}</strong><br>${date.toLocaleDateString(undefined,{month:"short",day:"numeric"})}</div>${daily.length?daily.map(item=>`<button class="calendar-event ${item.status==="completed"?"completed":""}" data-action="schedule-details" data-id="${esc(item.id)}">${esc(item.time?`${item.time} · `:"")}${esc(item.routineName)}${item.status==="completed"?" ✓":item.date<localDate()?" · MISSED":""}</button>`).join(""):`<span class="text-muted" style="font-size:9px">No session</span>`}</div>`;}).join("")}</div>
      <div class="notice" style="margin-top:15px"><strong>Missed a day?</strong> Reschedule from a session's details. Nothing is recorded as complete until you explicitly finish the workout.</div>`;
  }

  function renderSettings() {
    const prefs=settings();
    const sounds=window.FittrackSounds?.getPreferences()||{enabled:true,volume:.42,click:true,success:true,pulse:true};
    const soundToggle=(name,label,description)=>`<div class="sound-setting-row"><div class="sound-setting-copy"><strong>${label}</strong><small>${description}</small></div><div class="sound-control"><button class="btn btn-small sound-preview" type="button" data-action="sound-preview" data-sound="${name}">Preview</button><input type="checkbox" aria-label="Enable ${label}" data-sound-toggle="${name}" ${sounds[name]?"checked":""}></div></div>`;
    return `<div class="view-intro"><div><h2 class="section-title">Make it yours.</h2><p>Update your profile, preferences, and personal data controls.</p></div></div>
      <div class="grid dashboard-grid"><section class="card panel"><div class="panel-head"><h2 class="section-title">Profile settings</h2></div><form id="profile-form" class="form-grid"><div class="form-field"><label for="profile-name">FULL NAME</label><input class="field" id="profile-name" name="name" required value="${esc(user.name)}"></div><div class="form-field"><label for="profile-username">USERNAME</label><input class="field" id="profile-username" name="username" required pattern="[A-Za-z0-9_]{3,24}" value="${esc(user.username)}"></div><div class="form-field full"><label for="profile-email">EMAIL</label><input class="field" id="profile-email" name="email" type="email" required value="${esc(user.email)}"></div><div class="form-field"><label for="profile-goal">FITNESS GOAL</label><select id="profile-goal" name="goal" class="select">${["Muscle Building","Weight Management","Strength","Endurance","General Fitness","Flexibility"].map(x=>`<option ${prefs.goal===x?"selected":""}>${x}</option>`).join("")}</select></div><div class="form-field"><label for="profile-theme">VISUAL THEME</label><select id="profile-theme" name="theme" class="select"><option value="dark" ${prefs.theme!=="light"?"selected":""}>Night mode</option><option value="light" ${prefs.theme==="light"?"selected":""}>Day mode</option></select></div><div class="form-field full"><button class="btn btn-primary" type="submit">Save profile</button></div></form></section>
      <div class="grid"><section class="card panel"><div class="panel-head"><h2 class="section-title">Sound system</h2><span class="sound-state" id="sound-state">${sounds.enabled?"Sound on":"Muted"}</span></div><div class="sound-settings"><div class="sound-setting-row"><div class="sound-setting-copy"><strong>Master sound</strong><small>Enable or mute FITTRACK feedback.</small></div><div class="sound-control"><input type="checkbox" aria-label="Enable master sound" data-sound-master ${sounds.enabled?"checked":""}></div></div><div class="sound-setting-row"><div class="sound-setting-copy"><strong>Master volume</strong><small>Comfortable default: ${Math.round(sounds.volume*100)}%.</small></div><div class="sound-control"><input class="sound-range" type="range" min="0" max="1" step="0.01" value="${sounds.volume}" aria-label="Master volume" data-sound-volume></div></div>${soundToggle("click","Cyber Click","Short feedback for intentional interface actions.")}${soundToggle("success","Power-Up Success","Positive confirmation after completed actions.")}${soundToggle("pulse","Pulse Alert","Workout timer and session event alerts.")}</div></section><section class="card panel"><div class="panel-head"><h2 class="section-title">Data controls</h2></div><p class="text-muted" style="font-size:11px">Export your activity history to a CSV file, or clear this account's personal fitness records.</p><div class="grid"><button class="btn" data-action="export-csv">${ftIcon("save")}↓ Export activity CSV</button><button class="btn btn-danger ft-icon-button" data-action="clear-data">${ftIcon("delete","ft-icon-sm")}Clear my fitness data</button><button class="btn ft-icon-button" data-action=\"logout">${ftIcon("logout","ft-icon-sm")}Log out</button></div><hr class="divider"><div class="notice"><strong>Local-only storage.</strong> Your information remains in this browser and website origin. It won't sync between devices and may be removed if browser storage is cleared. Local browser accounts are not secure production authentication.</div></section>
      <section class="card panel"><div class="panel-head"><h2 class="section-title">Account access</h2></div><div class="list-row"><div class="avatar">${esc(user.name.split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase())}</div><div class="list-row-main"><strong>${esc(user.name)}</strong><small>@${esc(user.username)} · ${esc(user.email)}</small></div></div></section></div></div>`;
  }

  function showModal(title, subtitle, body, submitLabel = "Save") {
    closeModal();
    const root=$("#modal-root");
    const formActions = body.includes('id="modal-form"') ? `<div class="modal-actions"><button type="button" class="btn btn-quiet" data-close-modal>Cancel</button><button type="submit" form="modal-form" class="btn btn-primary">${esc(submitLabel)}</button></div>` : "";
    root.innerHTML=`<div class="modal-backdrop" data-close-modal><section class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-head"><div><h2>${esc(title)}</h2><p>${esc(subtitle)}</p></div><button type="button" class="icon-btn" data-close-modal aria-label="Close">×</button></div>${body}${formActions}</section></div>`;
    decorateArrowButtons(root);
    const onRootClick=event=>{if(event.target.matches("[data-close-modal]")){window.FittrackSounds?.activate();window.FittrackSounds?.playClick();closeModal();}};
    const onKeyDown=event=>{
      if(event.key==="Escape"){event.preventDefault();closeModal();return;}
      if(event.key!=="Tab")return;
      const focusables=[...root.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter(el=>el.offsetParent!==null);
      if(!focusables.length)return;
      const first=focusables[0],last=focusables[focusables.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    };
    root.addEventListener("click",onRootClick);
    document.addEventListener("keydown",onKeyDown);
    root.addEventListener("submit",onModalSubmit);
    modalCleanup=()=>{
      document.removeEventListener("keydown",onKeyDown);
      root.innerHTML="";modalCleanup=null;
    };
    applyStagger(root, ".modal .form-field, .modal .list-row");
    const focus=$("input,select,textarea",root); if(focus)focus.focus();
  }
  function closeModal(){if(modalCleanup)modalCleanup();if(restTimer){clearInterval(restTimer);restTimer=null;}}
  function field(name,label,value="",type="text",required=true,extra="") { return `<div class="form-field"><label for="f-${name}">${label}</label><input class="field" id="f-${name}" name="${name}" type="${type}" value="${esc(value)}" ${required?"required":""} ${extra}></div>`; }
  function selectField(name,label,options,value="") { return `<div class="form-field"><label for="f-${name}">${label}</label><select class="select" id="f-${name}" name="${name}" required>${options.map(x=>`<option value="${esc(x)}" ${x===value?"selected":""}>${esc(x)}</option>`).join("")}</select></div>`; }
  function openForm(kind,id=null) {
    const existing=id?({routine:routines(),activity:activities(),weight:weights(),exercise:customExercises(),schedule:schedules()}[kind]||[]).find(item=>item.id===id):null;
    let title="",subtitle="",body="",submit="Save";
    const formStart=`<form id="modal-form" class="form-grid" data-kind="${kind}" data-id="${esc(id||"")}">`;
    if(kind==="routine") {
      const selected=existing?.exercises||[];
      title=existing?"Edit workout":"Build a workout";subtitle="Name the session, pick its focus, then add exercises.";
      body=formStart+field("name","WORKOUT NAME",existing?.name||"","text",true,'maxlength="60"')+field("durationMinutes","ESTIMATED MINUTES",existing?.durationMinutes||30,"number",true,'min="1" max="600"')+selectField("goal","FITNESS GOAL",["Muscle Building","Weight Management","Strength","Endurance","General Fitness","Flexibility"],existing?.goal||settings().goal||"General Fitness")+selectField("difficulty","DIFFICULTY",["Beginner","Intermediate","Advanced"],existing?.difficulty||"Beginner")+field("target","TARGET MUSCLES",existing?.target||"","text",false,'placeholder="e.g. Legs + core"')+`<div class="form-field full"><label for="f-description">DESCRIPTION</label><textarea class="textarea" id="f-description" name="description">${esc(existing?.description||"")}</textarea></div><div class="form-field full"><label>EXERCISES</label><div id="routine-exercise-list">${selected.map((item,index)=>routineExerciseRow(item,index)).join("")}</div><div class="inline-actions" style="margin-top:8px"><select class="select" id="routine-add-select"><option value="">Choose an exercise…</option>${exerciseList().map(ex=>`<option value="${esc(ex.id)}">${esc(ex.name)}</option>`).join("")}</select><button type="button" class="btn btn-small" data-action="routine-add-exercise">Add</button></div></div>`;
    } else if(kind==="activity") {
      title=existing?"Edit activity":"Log an activity";subtitle="Record a completed workout or another kind of movement.";
      body=formStart+field("name","ACTIVITY NAME",existing?.name||"","text",true,'maxlength="70"')+selectField("type","ACTIVITY TYPE",["Strength Training","Cardio","Walking","Running","Cycling","Sports","Yoga","Stretching","Other"],existing?.type||"Strength Training")+field("date","DATE",existing?.date||localDate(),"date")+field("duration","DURATION (MINUTES)",existing?.duration||30,"number",true,'min="1" max="1440"')+selectField("intensity","INTENSITY",["Easy","Moderate","Hard"],existing?.intensity||"Moderate")+`<div class="form-field full"><label for="f-note">NOTES (OPTIONAL)</label><textarea class="textarea" id="f-note" name="note">${esc(existing?.note||"")}</textarea></div>`;
    } else if(kind==="weight") {
      title=existing?"Edit weight entry":"Add a weight entry";subtitle="A personal record for your own timeline.";
      body=formStart+field("value",`WEIGHT (${settings().unit||"kg"})`,existing?.value||"","number",true,'min="1" max="1000" step="0.1"')+field("date","MEASUREMENT DATE",existing?.date||localDate(),"date")+`<div class="form-field full"><label for="f-note">NOTE (OPTIONAL)</label><textarea class="textarea" id="f-note" name="note">${esc(existing?.note||"")}</textarea></div>`;
    } else if(kind==="exercise") {
      title=existing?"Edit custom exercise":"Create a custom exercise";subtitle="Make a move for your personal library.";
      body=formStart+field("name","EXERCISE NAME",existing?.name||"","text",true,'maxlength="60"')+selectField("category","CATEGORY",["Chest","Back","Shoulders","Arms","Legs","Core","Cardio","Full Body","Flexibility"],existing?.category||"Full Body")+field("muscles","TARGET MUSCLES",existing?.muscles||"","text",true)+field("equipment","EQUIPMENT",existing?.equipment||"None","text",true)+selectField("difficulty","DIFFICULTY",["Beginner","Intermediate","Advanced"],existing?.difficulty||"Beginner")+field("suggested","SUGGESTED SETS / REPS",existing?.suggested||"3 × 10","text",true)+`<div class="form-field full"><label for="f-description">DESCRIPTION / INSTRUCTIONS</label><textarea class="textarea" id="f-description" name="description" required>${esc(existing?.description||"")}</textarea></div>`;
    } else if(kind==="schedule") {
      title="Schedule a workout";subtitle="Plan a routine. Completing it later is a separate action.";
      body=formStart+selectField("routineId","ROUTINE",routines().map(r=>`${r.id}|${r.name}`),existing?.routineId?`${existing.routineId}|${existing.routineName}`:"")+field("date","DATE",existing?.date||localDate(),"date")+field("time","START TIME",existing?.time||"","time",false)+`<div class="form-field full"><label for="f-note">NOTE (OPTIONAL)</label><textarea class="textarea" id="f-note" name="note">${esc(existing?.note||"")}</textarea></div>`;
    }
    body+=`</form>`;
    showModal(title,subtitle,body,submit);
    if(kind==="schedule") {
      const select=$("#f-routineId");if(select)select.innerHTML=`<option value="">Choose routine…</option>${routines().map(r=>`<option value="${esc(r.id)}" ${existing?.routineId===r.id?"selected":""}>${esc(r.name)}</option>`).join("")}`;
    }
    if(kind==="routine") attachReorderHandlers();
  }
  function routineExerciseRow(item,index) {
    const exercise=exerciseById(item.exerciseId);
    if(!exercise)return "";
    return `<div class="list-row routine-ex-row" data-exercise-id="${esc(item.exerciseId)}"><div class="list-row-main"><strong>${esc(exercise.name)}</strong><small>${esc(exercise.category)}</small></div><label class="text-muted">Sets <input class="field" data-exercise-value="sets" type="number" min="1" max="30" value="${Number(item.sets)||3}" style="width:58px;min-height:30px;padding:4px"></label><label class="text-muted">Reps <input class="field" data-exercise-value="reps" value="${esc(item.reps||"10")}" style="width:65px;min-height:30px;padding:4px"></label><label class="text-muted">Rest <input class="field" data-exercise-value="restSeconds" type="number" min="0" max="600" value="${item.restSeconds??60}" style="width:58px;min-height:30px;padding:4px"></label><button type="button" class="btn btn-small" data-action="move-exercise" data-direction="-1">↑</button><button type="button" class="btn btn-small" data-action="move-exercise" data-direction="1">↓</button><button type="button" class="btn btn-small btn-quiet btn-danger" data-action="remove-exercise">×</button></div>`;
  }
  function attachReorderHandlers() { /* The modal's shared event delegation handles ordering. */ }

  function onModalSubmit(event) {
    if(event.target.id!=="modal-form")return;
    event.preventDefault();
    const form=event.target, kind=form.dataset.kind, id=form.dataset.id;
    const data=Object.fromEntries(new FormData(form).entries());
    if(kind==="routine") {
      const exerciseRows=[...$("#routine-exercise-list").querySelectorAll(".routine-ex-row")].map(row=>{const rest=$('[data-exercise-value="restSeconds"]',row).value;return {exerciseId:row.dataset.exerciseId,sets:Number($('[data-exercise-value="sets"]',row).value),reps:$('[data-exercise-value="reps"]',row).value.trim(),restSeconds:rest===""?60:Number(rest)};});
      if(!exerciseRows.length)return toast("Add at least one exercise.");
      if(!data.name.trim())return toast("Give your workout a name.");
      const list=routines(), old=list.find(x=>x.id===id), now=new Date().toISOString();
      const item={...(old||{}),id:id||uid("routine"),userId:user.id,name:data.name.trim(),description:data.description.trim(),goal:data.goal,difficulty:data.difficulty,target:data.target.trim(),durationMinutes:Number(data.durationMinutes),exercises:exerciseRows,createdAt:old?.createdAt||now,updatedAt:now};
      saveOwned(KEYS.routines,old?list.map(x=>x.id===id?item:x):[...list,item]);closeModal();renderView();toast(old?"Workout updated.":"Workout added to your deck.");
    } else if(kind==="activity") {
      const list=activities(),old=list.find(x=>x.id===id),item={...(old||{}),id:id||uid("activity"),userId:user.id,name:data.name.trim(),type:data.type,date:data.date,duration:Number(data.duration),intensity:data.intensity,note:data.note.trim(),createdAt:old?.createdAt||new Date().toISOString()};
      saveOwned(KEYS.activities,old?list.map(x=>x.id===id?item:x):[...list,item]);closeModal();renderView();toast("Activity saved.");
    } else if(kind==="weight") {
      const list=weights(),old=list.find(x=>x.id===id),item={...(old||{}),id:id||uid("weight"),userId:user.id,value:Number(data.value),date:data.date,note:data.note.trim()};
      saveOwned(KEYS.weights,old?list.map(x=>x.id===id?item:x):[...list,item]);closeModal();renderView();toast("Weight entry saved.");
    } else if(kind==="exercise") {
      const list=customExercises(),old=list.find(x=>x.id===id),item={...(old||{}),id:id||uid("custom-exercise"),userId:user.id,name:data.name.trim(),category:data.category,muscles:data.muscles.trim(),equipment:data.equipment.trim(),difficulty:data.difficulty,suggested:data.suggested.trim(),description:data.description.trim(),instructions:data.description.trim()};
      saveOwned(KEYS.exercises,old?list.map(x=>x.id===id?item:x):[...list,item]);closeModal();renderView();toast("Exercise saved to your library.");
    } else if(kind==="schedule") {
      if(!data.routineId)return toast("Choose a routine to schedule.");
      const routine=routines().find(x=>x.id===data.routineId);if(!routine)return toast("That routine could not be found.");
      const list=schedules(),old=list.find(x=>x.id===id),item={...(old||{}),id:id||uid("schedule"),userId:user.id,routineId:routine.id,routineName:routine.name,date:data.date,time:data.time,note:data.note.trim(),status:old?.status||"upcoming"};
      saveOwned(KEYS.calendar,old?list.map(x=>x.id===id?item:x):[...list,item]);closeModal();renderView();toast("Workout scheduled.");
    }
  }

  function onAppSubmit(event) {
    if(event.target.id==="profile-form") {
      event.preventDefault();const data=Object.fromEntries(new FormData(event.target).entries());const users=read(KEYS.users);
      const username=data.username.trim(),email=data.email.trim().toLowerCase();
      if(users.some(item=>item.id!==user.id&&item.username.toLowerCase()===username.toLowerCase()))return toast("That username is already in use.");
      if(users.some(item=>item.id!==user.id&&item.email.toLowerCase()===email))return toast("That email is already in use.");
      user={...user,name:data.name.trim(),username,email};write(KEYS.users,users.map(item=>item.id===user.id?user:item));saveSettings({goal:data.goal,theme:data.theme});renderApp();toast("Profile updated.");
    }
  }
  function onAppChange(event) {
    if(event.target.matches("[data-sound-master]")){window.FittrackSounds?.setSoundsEnabled(event.target.checked);renderView();return;}
    if(event.target.matches("[data-sound-volume]")){window.FittrackSounds?.setMasterVolume(event.target.value);return;}
    if(event.target.matches("[data-sound-toggle]")){window.FittrackSounds?.setSoundEnabled(event.target.dataset.soundToggle,event.target.checked);return;}
    if(event.target.id==="weight-unit"){ 
      const from=settings().unit||"kg",to=event.target.value;
      if(from!==to){
        const factor=from==="kg"?2.2046226218:1/2.2046226218;
        saveOwned(KEYS.weights,weights().map(entry=>({...entry,value:Math.round(Number(entry.value)*factor*10)/10})));
        saveSettings({unit:to});
        renderView();
      }
    }
    if(event.target.id==="profile-theme"){applyTheme();if(view==="progress"){drawWeightChart();drawWorkoutFrequency();}}
    if(event.target.id==="progress-range")drawWeightChart();
  }
  function onAppClick(event) {
    window.FittrackSounds?.activate();
    const preview=event.target.closest("[data-action='sound-preview']");
    if(preview){const sound=preview.dataset.sound;window.FittrackSounds?.[sound === "click" ? "playClick" : sound === "success" ? "playSuccess" : "playPulse"]();return;}
    const viewButton=event.target.closest("[data-view]");
    if(viewButton){event.preventDefault();window.FittrackSounds?.playClick();view=viewButton.dataset.view;renderView();return;}
    const modalButton=event.target.closest("[data-modal]");
    if(modalButton){window.FittrackSounds?.playClick();openForm(modalButton.dataset.modal);return;}
    const button=event.target.closest("[data-action]");if(!button||button.disabled)return;
    const {action,id}=button.dataset;
    if(action!=="sound-preview")window.FittrackSounds?.playClick();
    if(action==="logout"){if(confirm("Log out? Your locally saved fitness records will remain on this device.")){user=null;activeSession=null;localStorage.removeItem(KEYS.session);sessionStorage.removeItem(KEYS.session);authMode="login";renderAuth();}return;}
    if(action==="edit-routine"){openForm("routine",id);return;}
    if(action==="delete-routine"){if(confirm("Delete this workout routine? Completed activities will stay in your log.")){saveOwned(KEYS.routines,routines().filter(x=>x.id!==id));renderView();toast("Workout deleted.");}return;}
    if(action==="duplicate-routine"){const item=routines().find(x=>x.id===id);if(item){const copy={...item,id:uid("routine"),name:`${item.name} (copy)`,createdAt:new Date().toISOString()};saveOwned(KEYS.routines,[...routines(),copy]);renderView();toast("Workout duplicated.");}return;}
    if(action==="edit-activity"){openForm("activity",id);return;}
    if(action==="delete-activity"){if(confirm("Delete this activity record?")){saveOwned(KEYS.activities,activities().filter(x=>x.id!==id));renderView();toast("Activity deleted.");}return;}
    if(action==="edit-weight"){openForm("weight",id);return;}
    if(action==="delete-weight"){if(confirm("Delete this weight entry?")){saveOwned(KEYS.weights,weights().filter(x=>x.id!==id));renderView();toast("Weight entry deleted.");}return;}
    if(action==="edit-exercise"){openForm("exercise",id);return;}
    if(action==="delete-exercise"){if(confirm("Delete this custom exercise? It will be removed from any routines that use it.")){saveOwned(KEYS.exercises,customExercises().filter(x=>x.id!==id));saveOwned(KEYS.routines,routines().map(r=>({...r,exercises:r.exercises.filter(e=>e.exerciseId!==id)})));renderView();toast("Custom exercise deleted.");}return;}
    if(action==="favorite-exercise"){const favorites=settings().favorites||[];saveSettings({favorites:favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id]});renderView();return;}
    if(action==="exercise-details"){const ex=exerciseById(id);if(ex)showInfo(ex.name,`${ex.category} · ${ex.difficulty}`,`<p class="text-muted">${esc(ex.instructions||ex.description)}</p><div class="tag-row"><span class="tag">${esc(ex.muscles)}</span><span class="tag">${esc(ex.equipment)}</span><span class="tag">${esc(ex.suggested)}</span></div>`);return;}
    if(action==="add-exercise-to-routine"){openForm("routine");setTimeout(()=>{const select=$("#routine-add-select");if(select){select.value=id;addRoutineExercise();}},0);return;}
    if(action==="routine-add-exercise"){addRoutineExercise();return;}
    if(action==="remove-exercise"){button.closest(".routine-ex-row").remove();return;}
    if(action==="move-exercise"){const row=button.closest(".routine-ex-row"), parent=row.parentElement, sibling=Number(button.dataset.direction)<0?row.previousElementSibling:row.nextElementSibling;if(sibling){if(Number(button.dataset.direction)<0)parent.insertBefore(row,sibling);else parent.insertBefore(sibling,row);}return;}
    if(action==="start-workout"){startWorkout(id);return;}
    if(action==="session-set"){const check=button;check.checked=!check.checked;updateSessionProgress();return;}
    if(action==="session-toggle-pause"){
      if(activeSession.pausedAt){
        activeSession.pausedMilliseconds+=Date.now()-activeSession.pausedAt;
        activeSession.pausedAt=null;
      }else{
        activeSession.pausedAt=Date.now();
        if(restTimer){clearInterval(restTimer);restTimer=null;}
      }
      renderWorkoutStep();return;
    }
    if(action==="session-next"){sessionNext();return;}
    if(action==="session-cancel"){if(confirm("Cancel this workout? It won't be recorded as completed.")){closeModal();activeSession=null;}return;}
    if(action==="rest-start"){runRestTimer();return;}
    if(action==="rest-reset"){if(restTimer)clearInterval(restTimer);restTimer=null;const el=$("#rest-clock");if(el)el.textContent="01:00";return;}
    if(action==="schedule-details"){scheduleDetails(id);return;}
    if(action==="calendar-shift"){const offset=Number(button.dataset.offset);$("#content").innerHTML=renderCalendar(offset);return;}
    if(action==="mark-scheduled"){const item=schedules().find(x=>x.id===id);if(item){startWorkout(item.routineId, item.id);}return;}
    if(action==="reschedule"){const item=schedules().find(x=>x.id===id);if(item){closeModal();openForm("schedule",id);}return;}
    if(action==="delete-schedule"){if(confirm("Delete this scheduled workout?")){saveOwned(KEYS.calendar,schedules().filter(x=>x.id!==id));closeModal();renderView();toast("Schedule removed.");}return;}
    if(action==="export-csv"){exportCSV();return;}
    if(action==="clear-data"){if(confirm("Delete all your routines, custom exercises, activities, weight entries, and calendar sessions? Your profile will remain.")){for(const key of [KEYS.routines,KEYS.exercises,KEYS.activities,KEYS.weights,KEYS.calendar])saveOwned(key,[]);renderView();toast("Your fitness records were cleared.");}return;}
  }
  function addRoutineExercise() {
    const select=$("#routine-add-select"), list=$("#routine-exercise-list");if(!select||!list||!select.value)return;
    if([...list.querySelectorAll(".routine-ex-row")].some(row=>row.dataset.exerciseId===select.value)){toast("That move is already in this routine.");select.value="";return;}
    list.insertAdjacentHTML("beforeend",routineExerciseRow({exerciseId:select.value,sets:3,reps:"10"},list.children.length));select.value="";
  }

  function showInfo(title,subtitle,body) {
    showModal(title,subtitle,`<div>${body}</div><div class="modal-actions"><button type="button" class="btn btn-quiet" data-close-modal>Close</button></div>`);
  }
  function startWorkout(routineId,scheduleId=null) {
    const routine=routines().find(x=>x.id===routineId);
    if(!routine||!routine.exercises.length)return toast("Add at least one move to this routine before starting.");
    activeSession={routine,scheduleId,index:0,setsDone:{},notes:"",startedAt:Date.now(),pausedAt:null,pausedMilliseconds:0};
    renderWorkoutStep();
  }
  function renderWorkoutStep() {
    if(!activeSession)return;
    const session=activeSession, routine=session.routine, item=routine.exercises[session.index], exercise=exerciseById(item.exerciseId);
    if(!exercise){sessionNext();return;}
    const done=Object.values(session.setsDone).reduce((sum,value)=>sum+value,0);
    const total=routine.exercises.reduce((sum,entry)=>sum+(Number(entry.sets)||1),0);
    const checked=session.setsDone[`${session.index}`]||0;
    const body=`<div class="eyebrow">MOVE ${session.index+1} / ${routine.exercises.length} · ${esc(routine.name)}</div><h2 style="font:800 37px/.95 'Barlow Condensed';text-transform:uppercase;margin:9px 0">${esc(exercise.name)}</h2><p class="text-muted">${esc(exercise.instructions||exercise.description)}</p><div class="tag-row"><span class="tag">${esc(item.sets)} sets</span><span class="tag">${esc(item.reps)} reps</span><span class="tag">${Number.isFinite(Number(item.restSeconds))?Number(item.restSeconds):60}s rest</span></div><div class="session-progress"><span style="width:${total?done/total*100:0}%"></span></div><p class="text-muted">${done} of ${total} sets complete</p>${Array.from({length:Number(item.sets)||1},(_,set)=>`<label class="set-row"><span>Set ${set+1} · ${esc(item.reps)} reps</span><input type="checkbox" data-session-set="${set}" ${set<checked?"checked":""} ${session.pausedAt?"disabled":""}></label>`).join("")}<div class="panel" style="margin-top:14px;background:var(--surface-2)"><div class="panel-head"><strong>Rest timer</strong><span id="rest-clock">01:00</span></div><div class="inline-actions"><button class="btn btn-small" data-action="rest-start" ${session.pausedAt?"disabled":""}>Start rest</button><button class="btn btn-small" data-action="rest-reset" ${session.pausedAt?"disabled":""}>Reset</button></div></div>`;
    showModal("Workout in progress",`${routine.name} · ${Math.floor(sessionElapsedMilliseconds()/60000)} min elapsed${session.pausedAt?" · PAUSED":""}`,`${body}${session.pausedAt?'<div class="notice">Session paused. Resume when you are ready to continue.</div>':""}<div class="modal-actions"><button type="button" class="btn btn-danger" data-action="session-cancel">Cancel workout</button><button type="button" class="btn" data-action="session-toggle-pause">${session.pausedAt?"Resume":"Pause"}</button><button type="button" class="btn btn-primary" data-action="session-next">${session.index===routine.exercises.length-1?"Finish workout":"Next move →"}</button></div>`);
    const actions=$(".modal-actions",$("#modal-root"));if(actions)actions.remove();
    const modal=$(".modal",$("#modal-root"));
    modal.insertAdjacentHTML("beforeend",`<div class="modal-actions"><button type="button" class="btn btn-danger" data-action="session-cancel">Cancel workout</button><button type="button" class="btn" data-action="session-toggle-pause">${session.pausedAt?"Resume":"Pause"}</button><button type="button" class="btn btn-primary" data-action="session-next">${session.index===routine.exercises.length-1?"Finish workout":"Next move →"}</button></div>`);
    modal.addEventListener("change",event=>{if(event.target.matches("[data-session-set]")){const checks=[...modal.querySelectorAll("[data-session-set]")];let count=0;for(const input of checks){if(input.checked)count++;else break;}session.setsDone[`${session.index}`]=count;updateSessionProgress();}});
  }
  function updateSessionProgress(){const modal=$("#modal-root .modal");if(!modal||!activeSession)return;const done=Object.values(activeSession.setsDone).reduce((sum,value)=>sum+value,0);const total=activeSession.routine.exercises.reduce((sum,entry)=>sum+(Number(entry.sets)||1),0);const bar=$(".session-progress span",modal);if(bar)bar.style.width=`${total?done/total*100:0}%`;const label=modal.querySelector(".text-muted");if(label)label.textContent=`${done} of ${total} sets complete`;}
  function sessionElapsedMilliseconds() {
    if(!activeSession)return 0;
    const end=activeSession.pausedAt||Date.now();
    return end-activeSession.startedAt-activeSession.pausedMilliseconds;
  }
  function sessionNext() {
    if(!activeSession)return;
    if(activeSession.pausedAt)return toast("Resume the session before continuing.");
    const current=activeSession.routine.exercises[activeSession.index];
    if((activeSession.setsDone[`${activeSession.index}`]||0)<(Number(current.sets)||1))return toast("Complete every set before moving on.");
    if(activeSession.index<activeSession.routine.exercises.length-1){activeSession.index++;renderWorkoutStep();return;}
    const session=activeSession,routine=session.routine,duration=Math.max(1,Math.round(sessionElapsedMilliseconds()/60000));
    const item={id:uid("activity"),userId:user.id,name:routine.name,type:"Strength Training",date:localDate(),duration,intensity:routine.difficulty==="Advanced"?"Hard":"Moderate",note:`Completed ${routine.exercises.length} exercise${routine.exercises.length===1?"":"s"}.`,routineId:routine.id,exerciseCount:routine.exercises.length,createdAt:new Date().toISOString()};
    saveOwned(KEYS.activities,[...activities(),item]);
    if(session.scheduleId)saveOwned(KEYS.calendar,schedules().map(entry=>entry.id===session.scheduleId?{...entry,status:"completed"}:entry));
    closeModal();activeSession=null;
    window.FittrackSounds?.playSuccess();
    showInfo("Session complete","Nice work. Your activity has been saved.",`<div class="hero-kicker">SESSION COMPLETE</div><h2 class="hero-title" style="font-size:48px">${esc(routine.name)}</h2><p class="text-muted">${duration} minutes · ${routine.exercises.length} exercises</p><p>${esc(item.note)}</p><button class="btn btn-primary" data-close-modal>Back to training</button>`);
    renderView();
  }
  function runRestTimer() {
    if(restTimer)clearInterval(restTimer);
    let seconds=60;const clock=$("#rest-clock");if(clock)clock.textContent="01:00";
    restTimer=setInterval(()=>{seconds--;const target=$("#rest-clock");if(target)target.textContent=`${String(Math.floor(seconds/60)).padStart(2,"0")}:${String(seconds%60).padStart(2,"0")}`;if(seconds<=0){clearInterval(restTimer);restTimer=null;window.FittrackSounds?.playPulse();toast("Rest timer complete.");}},1000);
  }
  function scheduleDetails(id) {
    const item=schedules().find(x=>x.id===id);if(!item)return;
    const overdue=item.date<localDate()&&item.status!=="completed";
    const content=`<div class="list-row"><div class="row-icon">${ftIcon("routines","ft-icon-sm")} ·</div><div class="list-row-main"><strong>${esc(item.routineName)}</strong><small>${fmtDate(item.date,{weekday:"long",month:"long",day:"numeric",year:"numeric"})}${item.time?` · ${esc(item.time)}`:""}</small></div><span class="tag">${item.status==="completed"?"COMPLETED":overdue?"MISSED":"UPCOMING"}</span></div>${item.note?`<p class="text-muted">${esc(item.note)}</p>`:""}<div class="modal-actions"><button class="btn btn-quiet" data-action="delete-schedule" data-id="${esc(id)}">Delete</button>${overdue?`<button class="btn" data-action="reschedule" data-id="${esc(id)}">Reschedule</button>`:""}${item.status!=="completed"?`<button class="btn btn-primary" data-action="mark-scheduled" data-id="${esc(id)}">Start workout</button>`:""}</div>`;
    showModal("Scheduled session", "Calendar plan", content);
  }

  function filterExercises() {
    const query=($("#exercise-search")?.value||"").trim().toLowerCase(),category=$("#exercise-category")?.value||"",difficulty=$("#exercise-difficulty")?.value||"",equipment=$("#exercise-equipment")?.value||"";
    document.querySelectorAll("[data-exercise-card]").forEach(card=>{card.hidden=!(card.dataset.search.includes(query)&&(!category||card.dataset.category===category)&&(!difficulty||card.dataset.difficulty===difficulty)&&(!equipment||card.dataset.equipment===equipment));});
  }
  function filterActivities() {
    const query=($("#activity-search")?.value||"").toLowerCase(),type=$("#activity-type-filter")?.value||"",from=$("#activity-from")?.value||"",to=$("#activity-to")?.value||"",sort=$("#activity-sort")?.value||"date";
    const list=activities().filter(x=>(`${x.name} ${x.note||""}`.toLowerCase().includes(query))&&(!type||x.type===type)&&(!from||x.date>=from)&&(!to||x.date<=to)).sort((a,b)=>sort==="duration"?Number(b.duration)-Number(a.duration):b.date.localeCompare(a.date));
    $("#activity-list").innerHTML=list.length?list.map(item=>activityRow(item,true)).join(""):`<div class="empty-state">No activity matches those filters.</div>`;
  }
  function exportCSV() {
    const list=activities();if(!list.length)return toast("There are no activity records to export.");
    const quote=value=>`"${String(value??"").replace(/"/g,'""')}"`;
    const rows=[["Date","Activity","Type","Duration minutes","Intensity","Notes"],...list.sort((a,b)=>a.date.localeCompare(b.date)).map(x=>[x.date,x.name,x.type,x.duration,x.intensity,x.note||""])].map(row=>row.map(quote).join(",")).join("\r\n");
    const blob=new Blob(["\uFEFF"+rows],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),link=document.createElement("a");
    link.href=url;link.download=`fittrack-activities-${localDate()}.csv`;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast("Activity CSV exported.");
  }

  document.addEventListener("input",event=>{if(event.target.matches("#exercise-search"))filterExercises();if(event.target.matches("#activity-search"))filterActivities();});
  document.addEventListener("pointerdown",event=>{
    const button=event.target.closest("button");
    if(!button)return;
    button.classList.remove("is-clicked");
    void button.offsetWidth;
    button.classList.add("is-clicked");
  },true);
  document.addEventListener("animationend",event=>{
    if(event.animationName==="click-pop")event.target.classList.remove("is-clicked");
  });
  document.addEventListener("change",event=>{if(["exercise-category","exercise-difficulty","exercise-equipment"].includes(event.target.id))filterExercises();if(["activity-type-filter","activity-from","activity-to","activity-sort"].includes(event.target.id))filterActivities();});
  window.addEventListener("resize",()=>{if(view==="progress"){drawWeightChart();drawWorkoutFrequency();}});
  restoreUser();
  if(user)renderApp();else renderAuth();
})();