(() => {
  "use strict";

  const STORAGE_KEY = "fittrack_sound_preferences";
  const DEFAULTS = { enabled: true, volume: 0.42, click: true, success: true, pulse: true };
  const state = { ...DEFAULTS, ...readPreferences() };
  let context = null;
  let master = null;
  let activeVoices = 0;
  let lastClickAt = 0;

  function readPreferences() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
      return saved && typeof saved === "object" ? saved : {};
    } catch (_) { return {}; }
  }

  function persist() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ enabled: state.enabled, volume: state.volume, click: state.click, success: state.success, pulse: state.pulse })); } catch (_) { /* Storage may be unavailable. */ }
  }

  function ensureContext() {
    if (!context) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return null;
      try {
        context = new AudioContextClass();
        master = context.createGain();
        master.gain.value = state.volume;
        master.connect(context.destination);
      } catch (_) { context = null; }
    }
    if (context && context.state === "suspended") context.resume().catch(() => {});
    return context;
  }

  function allowed(name) {
    return Boolean(state.enabled && state[name] && activeVoices < 8 && ensureContext());
  }

  function tone({ frequency, endFrequency = frequency, duration, type = "sine", gain = 0.08, delay = 0 }) {
    if (!context || !master) return;
    const start = context.currentTime + delay;
    const oscillator = context.createOscillator();
    const envelope = context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, start);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(35, endFrequency), start + duration);
    envelope.gain.setValueAtTime(0.0001, start);
    envelope.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), start + Math.min(0.012, duration * 0.2));
    envelope.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    oscillator.connect(envelope).connect(master);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.02);
  }

  function play(name, build) {
    if (!allowed(name)) return false;
    activeVoices += 1;
    try { build(); } catch (_) { /* Audio is enhancement-only. */ }
    window.setTimeout(() => { activeVoices = Math.max(0, activeVoices - 1); }, 760);
    return true;
  }

  function playClick() {
    const now = performance.now();
    if (now - lastClickAt < 55) return;
    lastClickAt = now;
    play("click", () => {
      tone({ frequency: 920, endFrequency: 650, duration: 0.075, type: "triangle", gain: 0.055 });
      tone({ frequency: 1850, endFrequency: 1200, duration: 0.045, type: "sine", gain: 0.018, delay: 0.004 });
    });
  }

  function playSuccess() {
    play("success", () => {
      tone({ frequency: 330, endFrequency: 390, duration: 0.28, type: "sine", gain: 0.08 });
      tone({ frequency: 495, endFrequency: 660, duration: 0.42, type: "triangle", gain: 0.065, delay: 0.12 });
      tone({ frequency: 990, endFrequency: 1320, duration: 0.3, type: "sine", gain: 0.045, delay: 0.28 });
    });
  }

  function playPulse() {
    play("pulse", () => {
      tone({ frequency: 220, endFrequency: 170, duration: 0.18, type: "sine", gain: 0.075 });
      tone({ frequency: 720, endFrequency: 560, duration: 0.13, type: "square", gain: 0.035, delay: 0.012 });
    });
  }

  window.FittrackSounds = {
    playClick,
    playSuccess,
    playPulse,
    setSoundsEnabled(enabled) { state.enabled = Boolean(enabled); persist(); },
    setMasterVolume(volume) { state.volume = Math.min(1, Math.max(0, Number(volume) || 0)); if (master) master.gain.setTargetAtTime(state.volume, context.currentTime, 0.02); persist(); },
    setSoundEnabled(name, enabled) { if (Object.prototype.hasOwnProperty.call(DEFAULTS, name)) state[name] = Boolean(enabled); persist(); },
    getPreferences() { return { ...state }; },
    activate() { ensureContext(); }
  };
})();
